<?php
/**
 * @package Optione
 */

dynamic_sidebar( optione()->get_sidebar() );