{
    "icons": [
	    "ecological",
		"bio-energy",
		"recycle",
		"factory",
		"eco-house",
		"green-energy",
		"solar-cell",
		"eco-friendly",
		"ecological-1",
		"ecological-2",
		"solar-energy",
		"solar-energy-1",
		"battery",
		"renewable-energy",
		"idea",
		"address",
		"mail",
		"calling",
		"twitter",
		"instagram",
		"facebook",
		"linkedin",
		"pinterest",
		"menu",
		"world",
		"right-arrow",
		"check",
		"play",
		"rating",
		"quote",
		"paper-plane",
		"right-arrow-1",
		"right",
		"follower",
		"coffee",
		"rocket",
		"next",
		"calendar",
		"calculator",
		"businessman",
		"right-quote",
		"phone-call",
		"energy",
		"solar-panel",
		"reliability",
		"operation",
		"medal",
		"wind-energy",
		"phone-call-1",
		"planet-earth"
	]
}


































