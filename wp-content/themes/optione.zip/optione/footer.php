<?php
/**
 * @package Optione
 */
?>
</div><!-- #main -->
<?php optione()->footer->getFooter(); ?>
</div>
<?php //do_action('pxl_anchor_target') 
	optione_action('anchor_target');
?>
<?php wp_footer(); ?>
</body>
</html>
